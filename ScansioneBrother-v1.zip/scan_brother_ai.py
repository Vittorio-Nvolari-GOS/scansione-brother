# -*- coding: utf-8 -*-
"""
============================================================================
 scan_brother_ai.py
 Scansione da scanner Brother (WIA) + OCR (Tesseract) + naming via LLM locale
 (Ollama), salvataggio PDF con nome riconosciuto automaticamente.
 Target: Windows 10/11.
============================================================================

----------------------------------------------------------------------------
 ISTRUZIONI DI INSTALLAZIONE (Windows)
----------------------------------------------------------------------------
 NOVITA': con CONFIG["AUTO_INSTALL"] = True (default) lo script prova a
 installare DA SOLO cio' che manca al primo avvio:
   - moduli Python (pip),
   - Tesseract-OCR (winget) + pacchetto lingua ita (download automatico),
   - Ollama (winget) + avvio servizio + 'ollama pull' del modello.
 Requisiti minimi perche' l'auto-install funzioni:
   - Python gia' installato (serve per eseguire lo script);
   - 'winget' presente (Windows 10/11 aggiornati: "App Installer" dallo Store);
   - connessione a Internet;
   - a volte serve avviare lo script come AMMINISTRATORE (per scrivere in
     "C:\\Program Files\\...") e/o RIAVVIARE il terminale dopo l'installazione
     di Tesseract/Ollama perche' il PATH venga aggiornato.
 Se preferisci fare tutto a mano, metti AUTO_INSTALL = False e segui i passi:

 1) Python 3.9+ per Windows (da https://www.python.org/, spunta "Add to PATH").

 2) Moduli Python (apri PowerShell o cmd):
        pip install pywin32 img2pdf pillow pytesseract requests
    NB: pywin32 serve per pilotare WIA via COM. Se dopo l'installazione COM
        desse errori, esegui una volta (come amministratore):
        python -m pywin32_postinstall -install

 3) Tesseract-OCR per Windows:
        - Scarica l'installer (UB-Mannheim):
          https://github.com/UB-Mannheim/tesseract/wiki
        - Durante l'installazione seleziona i pacchetti lingua "Italian" (ita)
          e "English" (eng).
        - Percorso di default atteso:
          C:\\Program Files\\Tesseract-OCR\\tesseract.exe
          (configurabile qui sotto in CONFIG -> TESSERACT_PATH)

 4) Ollama per Windows:
        - Scarica e installa da https://ollama.com/download
        - Avvia Ollama (di norma parte come servizio su http://localhost:11434)
        - Scarica un modello leggero:
              ollama pull llama3.2:3b
          oppure:
              ollama pull qwen2.5:3b

 5) (OPZIONALE) NAPS2 come fallback allo scanner:
        - Installa NAPS2 (https://www.naps2.com/)
        - Fornisce naps2.console.exe per scansione da riga di comando.
        - Vedi la funzione scansione_naps2_fallback() piu' in basso.

----------------------------------------------------------------------------
 AVVIO
----------------------------------------------------------------------------
 - Doppio click su "Avvia_Scansione.bat" (consigliato), oppure:
        python scan_brother_ai.py
 - Parametri opzionali da riga di comando:
        python scan_brother_ai.py --device-id "{ID}"  (forza un device)
        python scan_brother_ai.py --naps2             (usa il fallback NAPS2)
        python scan_brother_ai.py --list-devices      (elenca i device WIA)
============================================================================
"""

import os
import sys
import re
import json
import time
import logging
import argparse
import tempfile
import subprocess
from datetime import datetime

# ===========================================================================
# CONFIG  -- Modifica qui i parametri principali
# ===========================================================================
CONFIG = {
    # ID del device WIA da usare. Se vuoto ("") lo script rileva/chiede il Brother.
    # Puoi ottenerlo con: python scan_brother_ai.py --list-devices
    "DEVICE_ID": "",

    # Preferenza sul nome del produttore per l'auto-rilevamento
    "DEVICE_NAME_HINT": "brother",

    # Parametri di scansione
    "DPI": 300,                 # risoluzione
    "COLOR_MODE": "RGB",        # "RGB" (colore), "Grayscale", "BlackWhite"
    "PAGE_SIZE": "A4",          # A4 (usato per calcolo area flatbed)
    # Origine documenti:
    #   "Auto"    -> se l'ADF (alimentatore sopra) ha fogli caricati usa quello,
    #                altrimenti ripiega sul piano (flatbed). CONSIGLIATO.
    #   "Feeder"  -> forza l'ADF
    #   "Flatbed" -> forza il piano
    "SOURCE": "Auto",
    "MULTIPAGE": True,          # True = da Flatbed chiede se ci sono altri fogli

    # Cartelle
    "OUTPUT_DIR": os.path.join(os.path.expanduser("~"), "Documents", "Scansioni"),
    "LOG_DIR": os.path.join(os.path.expanduser("~"), "Scansioni", "log"),

    # OCR
    "TESSERACT_PATH": r"C:\Program Files\Tesseract-OCR\tesseract.exe",
    "OCR_LANG": "ita+eng",
    # Pre-elaborazione immagine prima dell'OCR: migliora molto la lettura di
    # documenti difficili come carta d'identita' e tessera sanitaria
    # (font piccoli, sfondi di sicurezza, poco contrasto). Metti False per
    # disattivarla.
    "OCR_PREPROCESS": True,
    # Ingrandisce l'immagine se e' piccola (aiuta l'OCR su testo minuto delle
    # tessere). 1.0 = nessun ingrandimento.
    "OCR_UPSCALE": 2.0,

    # LLM locale (Ollama)
    "OLLAMA_URL": "http://localhost:11434",
    "OLLAMA_MODEL": "llama3.2:3b",   # oppure "qwen2.5:3b"
    "OLLAMA_TIMEOUT": 120,           # secondi

    # Naming file
    "MAX_FILENAME_LEN": 60,

    # NAPS2 (fallback)
    "NAPS2_CONSOLE": r"C:\Program Files\NAPS2\naps2.console.exe",

    # ---- Auto-installazione dipendenze mancanti ----
    # Se True, lo script tenta di installare da solo cio' che manca:
    #   - moduli Python via pip
    #   - Tesseract-OCR via winget (+ download pacchetto lingua ita)
    #   - Ollama via winget (+ avvio servizio + ollama pull del modello)
    # Metti False se preferisci installare tutto manualmente.
    "AUTO_INSTALL": True,
}

# Costanti WIA (Windows Image Acquisition) -----------------------------------
WIA_FORMAT_JPEG = "{B96B3CAE-0728-11D3-9D7B-0000F81EF32E}"
WIA_FORMAT_PNG  = "{B96B3CAF-0728-11D3-9D7B-0000F81EF32E}"

# Proprieta' device/item WIA (property id)
WIA_DPS_DOCUMENT_HANDLING_SELECT = 3088   # 1=Feeder(ADF), 2=Flatbed
WIA_DPS_DOCUMENT_HANDLING_STATUS = 3087   # bit 0x01 = feeder pronto/carta presente
WIA_DPS_DOCUMENT_HANDLING_CAPS   = 3086   # bit 0x01 = FEEDER presente, 0x02 = FLATBED
FEEDER = 1
FLATBED = 2

WIA_IPS_CUR_INTENT   = 6146
WIA_IPS_XRES         = 6147
WIA_IPS_YRES         = 6148
WIA_IPS_XPOS         = 6149
WIA_IPS_YPOS         = 6150
WIA_IPS_XEXTENT      = 6151
WIA_IPS_YEXTENT      = 6152
WIA_IPA_DATATYPE     = 4103   # 0=BW, 2=Grayscale, 3=Color(RGB)

# Intent flags
WIA_INTENT_COLOR      = 1
WIA_INTENT_GRAYSCALE  = 2
WIA_INTENT_TEXT       = 4

# Dimensioni A4 in pixel a dato DPI (210 x 297 mm)
def a4_pixels(dpi):
    larghezza = int(round(8.27 * dpi))   # 210 mm  ~ 8.27"
    altezza   = int(round(11.69 * dpi))  # 297 mm  ~ 11.69"
    return larghezza, altezza


# ===========================================================================
# LOGGING
# ===========================================================================
def setup_logging(log_dir):
    """Configura logging su console + file con timestamp."""
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, "scan_brother_ai.log")

    logger = logging.getLogger("scan")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()

    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s",
                            datefmt="%Y-%m-%d %H:%M:%S")

    # Console
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    # File
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    logger.info("Log file: %s", log_file)
    return logger


# ===========================================================================
# BARRA DI AVANZAMENTO (per i download gestiti da Python)
# ===========================================================================
def _formato_byte(n):
    """Formatta un numero di byte in unita' leggibili."""
    for unita in ("B", "KB", "MB", "GB"):
        if n < 1024 or unita == "GB":
            return f"{n:.1f}{unita}"
        n /= 1024


def _barra_progresso(scaricato, totale, etichetta="", larghezza=30):
    """Disegna una barra di avanzamento su una singola riga del terminale.
    Se 'totale' e' sconosciuto (0), mostra solo i byte scaricati."""
    if totale > 0:
        frazione = min(scaricato / totale, 1.0)
        pieni = int(larghezza * frazione)
        barra = "#" * pieni + "-" * (larghezza - pieni)
        testo = (f"\r  {etichetta} [{barra}] {frazione*100:5.1f}%  "
                 f"{_formato_byte(scaricato)}/{_formato_byte(totale)}")
    else:
        testo = f"\r  {etichetta} ... {_formato_byte(scaricato)} scaricati"
    sys.stdout.write(testo)
    sys.stdout.flush()


def _fine_barra():
    """Chiude la riga della barra andando a capo."""
    sys.stdout.write("\n")
    sys.stdout.flush()


# ===========================================================================
# AUTO-INSTALLAZIONE DIPENDENZE
# ===========================================================================
def _comando_disponibile(nome):
    """True se un eseguibile e' raggiungibile nel PATH (usa 'where')."""
    try:
        r = subprocess.run(["where", nome], capture_output=True, text=True)
        return r.returncode == 0
    except Exception:
        return False


def _winget_disponibile(log):
    """Verifica che winget (gestore pacchetti Windows) sia presente."""
    if _comando_disponibile("winget"):
        return True
    log.warning("winget non disponibile: impossibile installare automaticamente "
                "programmi esterni. Su Windows 10/11 aggiorna 'App Installer' "
                "dal Microsoft Store.")
    return False


def _winget_install(package_id, log, extra_args=None):
    """Installa un pacchetto via winget. NON cattura l'output cosi' la barra
    di avanzamento nativa di winget resta visibile a schermo."""
    # Nota: niente --silent per mostrare il progresso del download.
    cmd = ["winget", "install", "--id", package_id, "-e",
           "--accept-package-agreements", "--accept-source-agreements"]
    if extra_args:
        cmd += extra_args
    log.info("winget: installazione '%s' in corso (puo' richiedere qualche minuto)...",
             package_id)
    print("-" * 60)
    try:
        # output lasciato scorrere sul terminale -> barra di winget visibile
        r = subprocess.run(cmd, timeout=900)
        print("-" * 60)
        if r.returncode not in (0,):
            log.warning("winget ha restituito codice %d per '%s'.",
                        r.returncode, package_id)
            return False
        return True
    except Exception as e:
        log.error("Esecuzione winget fallita per '%s': %s", package_id, e)
        return False


def _installa_moduli_python(mancanti, log):
    """Installa i moduli Python mancanti via pip nel Python corrente."""
    if not mancanti:
        return []
    pacchetti = sorted(set(mancanti.values()))
    log.info("Installazione moduli Python mancanti: %s", ", ".join(pacchetti))
    print("-" * 60)
    try:
        # output NON catturato -> pip mostra la sua barra di avanzamento
        cmd = [sys.executable, "-m", "pip", "install", "--upgrade"] + pacchetti
        r = subprocess.run(cmd, timeout=600)
        print("-" * 60)
        if r.returncode != 0:
            log.error("pip ha restituito codice di errore %d.", r.returncode)
    except Exception as e:
        log.error("Impossibile eseguire pip: %s", e)

    # Ricontrolla quali risultano ancora mancanti
    ancora = {}
    for modulo, pacchetto in mancanti.items():
        try:
            # invalida cache import per moduli appena installati
            import importlib
            importlib.invalidate_caches()
            __import__(modulo)
        except ImportError:
            ancora[modulo] = pacchetto
    return list(ancora.keys())


def _installa_tesseract(log):
    """Installa Tesseract-OCR via winget e scarica il pacchetto lingua ita."""
    if not _winget_disponibile(log):
        return False
    ok = _winget_install("UB-Mannheim.TesseractOCR", log)
    # winget puo' non aggiornare il PATH nella sessione corrente: il percorso
    # atteso resta CONFIG["TESSERACT_PATH"].
    if not os.path.isfile(CONFIG["TESSERACT_PATH"]):
        # prova percorso alternativo comune
        alt = os.path.expandvars(r"%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe")
        if os.path.isfile(alt):
            CONFIG["TESSERACT_PATH"] = alt
    return ok and os.path.isfile(CONFIG["TESSERACT_PATH"])


def _scarica_lingua_tesseract(lang, log):
    """Scarica il file <lang>.traineddata nella cartella tessdata di Tesseract."""
    import requests
    tess = CONFIG["TESSERACT_PATH"]
    tessdata = os.path.join(os.path.dirname(tess), "tessdata")
    os.makedirs(tessdata, exist_ok=True)
    destinazione = os.path.join(tessdata, f"{lang}.traineddata")
    if os.path.isfile(destinazione):
        return True
    url = f"https://github.com/tesseract-ocr/tessdata/raw/main/{lang}.traineddata"
    log.info("Scarico pacchetto lingua Tesseract '%s'...", lang)
    try:
        # stream=True per scaricare a blocchi e disegnare la barra
        r = requests.get(url, timeout=120, stream=True)
        r.raise_for_status()
        totale = int(r.headers.get("Content-Length", 0))
        scaricato = 0
        etichetta = f"{lang}.traineddata"
        with open(destinazione, "wb") as f:
            for blocco in r.iter_content(chunk_size=64 * 1024):
                if not blocco:
                    continue
                f.write(blocco)
                scaricato += len(blocco)
                _barra_progresso(scaricato, totale, etichetta)
        _fine_barra()
        log.info("Lingua '%s' installata in %s", lang, tessdata)
        return True
    except Exception as e:
        log.error("Download lingua '%s' fallito: %s "
                  "(potrebbe servire eseguire lo script come amministratore).",
                  lang, e)
        return False


def _avvia_ollama(log):
    """Avvia il servizio Ollama in background se non e' in esecuzione."""
    try:
        # 'ollama serve' avvia il server; su Windows l'app di norma lo fa gia'.
        subprocess.Popen(["ollama", "serve"],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        log.debug("Avvio 'ollama serve' non riuscito (forse gia' attivo): %s", e)


def _ollama_online(log):
    """True se l'endpoint Ollama risponde."""
    try:
        import requests
        r = requests.get(CONFIG["OLLAMA_URL"] + "/api/tags", timeout=5)
        return r.status_code == 200
    except Exception:
        return False


def _installa_ollama(log):
    """Installa Ollama via winget, lo avvia e attende che risponda."""
    if not _winget_disponibile(log):
        return False
    _winget_install("Ollama.Ollama", log)
    _avvia_ollama(log)
    # Attende l'avvio del servizio (fino a ~30s)
    for _ in range(15):
        if _ollama_online(log):
            return True
        time.sleep(2)
    return _ollama_online(log)


def _pull_modello_ollama(modello, log):
    """Scarica il modello LLM con 'ollama pull'."""
    log.info("Scarico il modello LLM '%s' (puo' richiedere diversi minuti)...",
             modello)
    try:
        r = subprocess.run(["ollama", "pull", modello], timeout=1800)
        return r.returncode == 0
    except Exception as e:
        log.error("'ollama pull %s' fallito: %s", modello, e)
        return False


# ===========================================================================
# CONTROLLO DIPENDENZE (all'avvio)  -- con auto-installazione
# ===========================================================================
def controlla_dipendenze(log, usa_naps2=False):
    """Verifica (e, se AUTO_INSTALL, installa) moduli Python, Tesseract e Ollama.
    Solleva RuntimeError con messaggi chiari se qualcosa resta irrisolto."""
    auto = CONFIG["AUTO_INSTALL"]
    problemi = []

    # --- Moduli Python -----------------------------------------------------
    moduli = {
        "win32com.client": "pywin32",
        "PIL": "pillow",
        "img2pdf": "img2pdf",
        "pytesseract": "pytesseract",
        "requests": "requests",
    }
    mancanti = {}
    for modulo, pacchetto in moduli.items():
        try:
            __import__(modulo)
        except ImportError:
            mancanti[modulo] = pacchetto

    if mancanti:
        if auto:
            log.info("Moduli Python mancanti: %s -> tento installazione automatica.",
                     ", ".join(mancanti.values()))
            residui = _installa_moduli_python(mancanti, log)
            for m in residui:
                problemi.append(
                    f"Modulo Python '{m}' non installabile automaticamente. "
                    f"Installa a mano: pip install {moduli[m]}"
                )
        else:
            for m, p in mancanti.items():
                problemi.append(f"Modulo Python mancante: '{m}'. pip install {p}")

    # --- Tesseract ---------------------------------------------------------
    if not os.path.isfile(CONFIG["TESSERACT_PATH"]):
        if auto:
            log.info("Tesseract non trovato -> tento installazione via winget.")
            if not _installa_tesseract(log):
                problemi.append(
                    f"Tesseract non installato automaticamente. Installa da "
                    f"https://github.com/UB-Mannheim/tesseract/wiki e/o correggi "
                    f"TESSERACT_PATH. NB: dopo l'installazione con winget puo' servire "
                    f"riavviare il terminale per aggiornare il PATH."
                )
        else:
            problemi.append(
                f"Tesseract non trovato in '{CONFIG['TESSERACT_PATH']}'. "
                f"Installa Tesseract-OCR o correggi TESSERACT_PATH."
            )

    # Pacchetti lingua OCR
    if os.path.isfile(CONFIG["TESSERACT_PATH"]):
        try:
            out = subprocess.run([CONFIG["TESSERACT_PATH"], "--list-langs"],
                                 capture_output=True, text=True, timeout=30)
            disponibili = out.stdout.lower()
            for lang in CONFIG["OCR_LANG"].split("+"):
                lang = lang.strip()
                if lang and lang not in disponibili:
                    if auto:
                        log.info("Lingua OCR '%s' mancante -> scarico.", lang)
                        if not _scarica_lingua_tesseract(lang, log):
                            problemi.append(
                                f"Pacchetto lingua Tesseract '{lang}' non installato. "
                                f"Scaricalo manualmente in tessdata."
                            )
                    else:
                        log.warning("Lingua Tesseract '%s' non trovata.", lang)
        except Exception as e:
            log.warning("Impossibile verificare le lingue Tesseract: %s", e)

    # --- Ollama ------------------------------------------------------------
    if not _ollama_online(log):
        if auto:
            log.info("Ollama non raggiungibile -> tento avvio/installazione.")
            _avvia_ollama(log)          # magari e' installato ma spento
            if not _ollama_online(log):
                _installa_ollama(log)
        if not _ollama_online(log):
            problemi.append(
                f"Ollama non raggiungibile su {CONFIG['OLLAMA_URL']}. "
                f"Installa da https://ollama.com/download e avvialo."
            )

    # Modello LLM
    if _ollama_online(log):
        try:
            import requests
            r = requests.get(CONFIG["OLLAMA_URL"] + "/api/tags", timeout=5)
            modelli = [m.get("name", "") for m in r.json().get("models", [])]
            log.info("Ollama online. Modelli: %s",
                     ", ".join(modelli) if modelli else "(nessuno)")
            presente = any(m == CONFIG["OLLAMA_MODEL"]
                           or m.split(":")[0] == CONFIG["OLLAMA_MODEL"].split(":")[0]
                           for m in modelli)
            if not presente:
                if auto:
                    if not _pull_modello_ollama(CONFIG["OLLAMA_MODEL"], log):
                        problemi.append(
                            f"Modello '{CONFIG['OLLAMA_MODEL']}' non scaricato. "
                            f"Esegui: ollama pull {CONFIG['OLLAMA_MODEL']}"
                        )
                else:
                    log.warning("Modello '%s' non presente. ollama pull %s",
                                CONFIG["OLLAMA_MODEL"], CONFIG["OLLAMA_MODEL"])
        except Exception as e:
            log.warning("Verifica modelli Ollama fallita: %s", e)

    # --- NAPS2 (solo se richiesto come fallback) ---------------------------
    if usa_naps2 and not os.path.isfile(CONFIG["NAPS2_CONSOLE"]):
        if auto and _winget_disponibile(log):
            log.info("NAPS2 non trovato -> tento installazione via winget.")
            _winget_install("Cyanfish.NAPS2", log)
        if not os.path.isfile(CONFIG["NAPS2_CONSOLE"]):
            problemi.append(
                f"NAPS2 console non trovato in '{CONFIG['NAPS2_CONSOLE']}'. "
                f"Installa NAPS2 o correggi NAPS2_CONSOLE."
            )

    if problemi:
        raise RuntimeError(
            "Controllo dipendenze fallito:\n  - " + "\n  - ".join(problemi)
        )

    log.info("Controllo dipendenze superato.")


# ===========================================================================
# SCANSIONE VIA WIA
# ===========================================================================
def elenca_device_wia(log=None):
    """Ritorna la lista dei device WIA come [(device_id, nome), ...]."""
    import win32com.client
    dm = win32com.client.Dispatch("WIA.DeviceManager")
    devices = []
    for i in range(1, dm.DeviceInfos.Count + 1):
        info = dm.DeviceInfos.Item(i)
        dev_id = info.DeviceID
        nome = ""
        try:
            # Property "Name" (id 7) descrive il device
            for j in range(1, info.Properties.Count + 1):
                p = info.Properties.Item(j)
                if p.Name.lower() in ("name", "description"):
                    nome = str(p.Value)
                    if p.Name.lower() == "name":
                        break
        except Exception:
            pass
        devices.append((dev_id, nome or "(sconosciuto)"))
    if log:
        for idx, (did, nome) in enumerate(devices, 1):
            log.info("  [%d] %s  ->  %s", idx, nome, did)
    return devices


def _imposta_proprieta(props, prop_id, valore, log):
    """Imposta una proprieta' WIA in modo tollerante (alcune non sono scrivibili
    su tutti i device Brother)."""
    try:
        for i in range(1, props.Count + 1):
            p = props.Item(i)
            if int(p.PropertyID) == prop_id:
                p.Value = valore
                return True
    except Exception as e:
        log.debug("Impossibile impostare property %s=%s: %s", prop_id, valore, e)
    return False


def _connetti_device(log, device_id_forzato=None):
    """Seleziona/collega il device Brother. Ritorna l'oggetto Device WIA."""
    import win32com.client

    device_id = device_id_forzato or CONFIG["DEVICE_ID"]
    devices = elenca_device_wia()

    if not devices:
        raise RuntimeError(
            "Nessuno scanner WIA rilevato. Verifica che lo scanner Brother sia "
            "acceso, collegato (USB/rete) e con i driver WIA installati."
        )

    scelto = None

    # 1) device id esplicito
    if device_id:
        for did, nome in devices:
            if did == device_id:
                scelto = (did, nome)
                break
        if not scelto:
            log.warning("DEVICE_ID '%s' non trovato tra i device disponibili.", device_id)

    # 2) auto-rilevamento Brother
    if not scelto:
        hint = CONFIG["DEVICE_NAME_HINT"].lower()
        candidati = [(did, nome) for did, nome in devices if hint in nome.lower()]
        if len(candidati) == 1:
            scelto = candidati[0]
            log.info("Device Brother rilevato automaticamente: %s", scelto[1])
        elif len(candidati) > 1:
            log.info("Piu' scanner Brother trovati:")
            scelto = _scegli_interattivo(candidati, log)

    # 3) scelta interattiva tra tutti
    if not scelto:
        log.info("Scanner disponibili:")
        scelto = _scegli_interattivo(devices, log)

    device_id_finale = scelto[0]
    log.info("Uso scanner: %s (%s)", scelto[1], device_id_finale)

    dm = win32com.client.Dispatch("WIA.DeviceManager")
    for i in range(1, dm.DeviceInfos.Count + 1):
        info = dm.DeviceInfos.Item(i)
        if info.DeviceID == device_id_finale:
            try:
                return info.Connect()
            except Exception as e:
                raise RuntimeError(
                    f"Impossibile connettersi allo scanner ({scelto[1]}). "
                    f"Potrebbe essere occupato da un altro programma o in errore. "
                    f"Dettagli: {e}"
                )
    raise RuntimeError("Device selezionato non piu' disponibile.")


def _scegli_interattivo(lista, log):
    """Chiede all'utente di scegliere un device dalla lista."""
    for idx, (did, nome) in enumerate(lista, 1):
        print(f"  [{idx}] {nome}")
    while True:
        try:
            scelta = input("Seleziona il numero dello scanner: ").strip()
            n = int(scelta)
            if 1 <= n <= len(lista):
                return lista[n - 1]
        except (ValueError, EOFError):
            pass
        print("Scelta non valida, riprova.")


def _configura_item(item, log):
    """Applica DPI, colore e area A4 all'item di scansione."""
    props = item.Properties
    dpi = CONFIG["DPI"]

    # Colore / tipo dato
    color_map = {"RGB": 3, "Grayscale": 2, "BlackWhite": 0}
    _imposta_proprieta(props, WIA_IPA_DATATYPE,
                       color_map.get(CONFIG["COLOR_MODE"], 3), log)

    # Risoluzione
    _imposta_proprieta(props, WIA_IPS_XRES, dpi, log)
    _imposta_proprieta(props, WIA_IPS_YRES, dpi, log)

    # Area A4 (origine 0,0 + estensione)
    w, h = a4_pixels(dpi)
    _imposta_proprieta(props, WIA_IPS_XPOS, 0, log)
    _imposta_proprieta(props, WIA_IPS_YPOS, 0, log)
    _imposta_proprieta(props, WIA_IPS_XEXTENT, w, log)
    _imposta_proprieta(props, WIA_IPS_YEXTENT, h, log)


def _device_ha_feeder(device):
    """True se lo scanner dichiara di avere un ADF (alimentatore)."""
    try:
        for i in range(1, device.Properties.Count + 1):
            p = device.Properties.Item(i)
            if int(p.PropertyID) == WIA_DPS_DOCUMENT_HANDLING_CAPS:
                # bit 0x01 = FEEDER presente
                return (int(p.Value) & 0x01) != 0
    except Exception:
        pass
    return False


def _imposta_origine(device, log):
    """Imposta l'origine documenti in base a CONFIG['SOURCE'].

    In modalita' 'Auto': se l'ADF (alimentatore sopra) e' presente e ha fogli
    caricati -> usa l'ADF; altrimenti usa il piano (flatbed).
    """
    modo = CONFIG["SOURCE"].lower()

    def _prova_feeder():
        """Tenta di impostare l'ADF; ritorna True se riuscito."""
        return _imposta_proprieta(device.Properties,
                                  WIA_DPS_DOCUMENT_HANDLING_SELECT, FEEDER, log)

    def _usa_flatbed():
        _imposta_proprieta(device.Properties,
                           WIA_DPS_DOCUMENT_HANDLING_SELECT, FLATBED, log)
        log.info("Origine: Flatbed (piano).")
        return "flatbed"

    # --- AUTO: preferisci l'ADF se ha carta ---
    if modo == "auto":
        if _device_ha_feeder(device) and _feeder_ha_carta(device):
            if _prova_feeder():
                log.info("Origine: ADF (rilevati fogli nell'alimentatore) -> "
                         "uso l'alimentatore invece del piano.")
                return "feeder"
            log.warning("Fogli nell'ADF ma impostazione ADF non riuscita: uso il piano.")
        else:
            log.info("ADF vuoto o assente: uso il piano (flatbed).")
        return _usa_flatbed()

    # --- FEEDER forzato ---
    if modo == "feeder":
        if _prova_feeder():
            log.info("Origine: ADF (Feeder) forzato.")
            return "feeder"
        log.warning("ADF non impostabile, ripiego sul piano (flatbed).")
        return _usa_flatbed()

    # --- FLATBED forzato (default) ---
    return _usa_flatbed()


def _feeder_ha_carta(device):
    """Controlla lo stato del feeder (bit 0x01 = documento presente)."""
    try:
        for i in range(1, device.Properties.Count + 1):
            p = device.Properties.Item(i)
            if int(p.PropertyID) == WIA_DPS_DOCUMENT_HANDLING_STATUS:
                return (int(p.Value) & 0x01) != 0
    except Exception:
        pass
    return False


def scansiona_wia(temp_dir, log, device_id_forzato=None):
    """Esegue la scansione (WIA) e ritorna la lista di percorsi immagine."""
    device = _connetti_device(log, device_id_forzato)
    origine = _imposta_origine(device, log)

    immagini = []
    pagina = 1

    while True:
        # Ottiene l'item da scansionare
        try:
            item = device.Items.Item(1)
        except Exception as e:
            raise RuntimeError(f"Impossibile ottenere l'item di scansione: {e}")

        _configura_item(item, log)

        log.info("Scansione pagina %d in corso...", pagina)
        try:
            image = item.Transfer(WIA_FORMAT_JPEG)
        except Exception as e:
            # Con ADF: quando la carta finisce, Transfer solleva eccezione -> stop
            if origine == "feeder" and pagina > 1:
                log.info("ADF vuoto: acquisizione terminata.")
                break
            raise RuntimeError(
                f"Errore durante la scansione (scanner occupato o carta assente?): {e}"
            )

        percorso = os.path.join(temp_dir, f"pagina_{pagina:03d}.jpg")
        # Rimuove eventuale file preesistente (WIA.SaveFile non sovrascrive)
        if os.path.exists(percorso):
            os.remove(percorso)
        image.SaveFile(percorso)
        immagini.append(percorso)
        log.info("Pagina %d salvata: %s", pagina, percorso)
        pagina += 1

        # Continuo?
        if origine == "feeder":
            if not _feeder_ha_carta(device):
                log.info("ADF vuoto: acquisizione terminata.")
                break
            # con alcuni driver conviene comunque tentare finche' Transfer fallisce
            continue

        if not CONFIG["MULTIPAGE"]:
            break

        risposta = input("Altra pagina da scansionare? [s/N]: ").strip().lower()
        if risposta not in ("s", "si", "sì", "y", "yes"):
            break

    if not immagini:
        raise RuntimeError("Nessuna pagina acquisita.")
    log.info("Acquisite %d pagina/e.", len(immagini))
    return immagini


# ===========================================================================
# FALLBACK: SCANSIONE VIA NAPS2 (console)
# ===========================================================================
def scansione_naps2_fallback(temp_dir, log):
    """
    Fallback con NAPS2 se WIA dà problemi col Brother.
    Documentazione naps2.console.exe:
      - Elenca driver/device:
          naps2.console.exe --listdevices --driver wia
      - Scansione diretta in PDF (piu' semplice):
          naps2.console.exe --driver wia --source glass \
              --dpi 300 --pagesize a4 --output "C:\\out\\scan.pdf"
        Per l'ADF usare: --source feeder
      - Profilo salvato in NAPS2 (consigliato per Brother):
          naps2.console.exe -p "NomeProfilo" -o "C:\\out\\scan.pdf"

    Qui produciamo direttamente un PDF temporaneo (NAPS2 gestisce multipagina
    da ADF nativamente). Ritorniamo il percorso del PDF.
    """
    pdf_temp = os.path.join(temp_dir, "naps2_scan.pdf")
    source = "feeder" if CONFIG["SOURCE"].lower() == "feeder" else "glass"
    cmd = [
        CONFIG["NAPS2_CONSOLE"],
        "--driver", "wia",
        "--source", source,
        "--dpi", str(CONFIG["DPI"]),
        "--pagesize", "a4",
        "--output", pdf_temp,
    ]
    log.info("Fallback NAPS2: %s", " ".join(cmd))
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    except Exception as e:
        raise RuntimeError(f"Esecuzione NAPS2 fallita: {e}")

    if res.returncode != 0 or not os.path.isfile(pdf_temp):
        raise RuntimeError(
            f"NAPS2 non ha prodotto il PDF. stdout={res.stdout} stderr={res.stderr}"
        )
    log.info("NAPS2 ha prodotto: %s", pdf_temp)
    return pdf_temp


# ===========================================================================
# UNIONE IMMAGINI -> PDF
# ===========================================================================
def immagini_in_pdf(immagini, pdf_out, log):
    """Unisce le immagini in un unico PDF. Usa img2pdf (qualita' migliore,
    nessuna ricompressione); fallback a Pillow."""
    try:
        import img2pdf
        with open(pdf_out, "wb") as f:
            f.write(img2pdf.convert(immagini))
        log.info("PDF creato con img2pdf: %s", pdf_out)
        return pdf_out
    except Exception as e:
        log.warning("img2pdf fallito (%s), provo con Pillow.", e)

    try:
        from PIL import Image
        pil = [Image.open(p).convert("RGB") for p in immagini]
        pil[0].save(pdf_out, save_all=True, append_images=pil[1:])
        log.info("PDF creato con Pillow: %s", pdf_out)
        return pdf_out
    except Exception as e:
        raise RuntimeError(f"Creazione PDF fallita: {e}")


# ===========================================================================
# OCR con Tesseract
# ===========================================================================
def _preprocessa_per_ocr(percorso, log):
    """Migliora l'immagine per l'OCR: scala di grigi, ingrandimento, nitidezza,
    contrasto automatico. Utile su carta d'identita'/tessera sanitaria.
    Ritorna un oggetto PIL.Image (in memoria, non tocca il file originale)."""
    from PIL import Image, ImageOps, ImageFilter
    img = Image.open(percorso)

    if not CONFIG.get("OCR_PREPROCESS", True):
        return img

    # 1) scala di grigi (toglie il rumore cromatico degli sfondi di sicurezza)
    img = ImageOps.grayscale(img)

    # 2) ingrandimento (il testo delle tessere e' minuto: piu' pixel = piu' OCR)
    fattore = float(CONFIG.get("OCR_UPSCALE", 1.0))
    if fattore and fattore > 1.0:
        nuova = (int(img.width * fattore), int(img.height * fattore))
        img = img.resize(nuova, Image.LANCZOS)

    # 3) contrasto automatico + nitidezza
    img = ImageOps.autocontrast(img, cutoff=1)
    img = img.filter(ImageFilter.SHARPEN)

    log.debug("Immagine pre-elaborata per OCR: %s -> %dx%d",
              os.path.basename(percorso), img.width, img.height)
    return img


def _ocr_migliore(img, log):
    """Esegue l'OCR con piu' modalita' di segmentazione (PSM) e restituisce il
    risultato piu' 'ricco'. I documenti-tessera non sono testo scorrevole, quindi
    la PSM giusta cambia molto il risultato:
      - psm 3 : pagina automatica (default)
      - psm 4 : colonna singola di testo di dimensioni variabili
      - psm 6 : blocco di testo uniforme
      - psm 11: testo sparso (ottimo per campi separati delle tessere)
    """
    import pytesseract
    migliore = ""
    for psm in (3, 4, 6, 11):
        cfg = f"--oem 1 --psm {psm}"
        try:
            testo = pytesseract.image_to_string(img, lang=CONFIG["OCR_LANG"], config=cfg)
        except Exception as e:
            log.debug("OCR psm %d fallito: %s", psm, e)
            continue
        # Euristica: preferisci il testo con piu' caratteri alfanumerici
        punteggio = sum(c.isalnum() for c in testo)
        if punteggio > sum(c.isalnum() for c in migliore):
            migliore = testo
    return migliore


def ocr_testo(immagini, log):
    """Esegue OCR (ita+eng) sulle immagini, con pre-elaborazione e scelta della
    migliore modalita' PSM. Ritorna il testo concatenato."""
    import pytesseract
    pytesseract.pytesseract.tesseract_cmd = CONFIG["TESSERACT_PATH"]

    testo_totale = []
    for idx, p in enumerate(immagini, 1):
        try:
            img = _preprocessa_per_ocr(p, log)
            testo = _ocr_migliore(img, log)
            testo_totale.append(testo)
            log.info("OCR pagina %d: %d caratteri estratti.", idx, len(testo))
        except Exception as e:
            log.error("OCR fallito su pagina %d: %s", idx, e)

    testo = "\n".join(testo_totale).strip()
    if not testo:
        log.warning("OCR non ha estratto testo (documento vuoto/immagine?).")
    return testo


def ocr_da_pdf(pdf_path, log):
    """OCR su un PDF (usato nel percorso NAPS2). Estrae le pagine come immagini
    tramite Tesseract non e' diretto: qui usiamo Pillow non e' sufficiente per
    PDF, quindi facciamo affidamento sul fatto che, nel percorso normale, l'OCR
    lavori sulle immagini. Se hai solo il PDF, converti con pdf2image (Poppler)
    oppure lascia che l'LLM lavori su meno testo. Qui tentiamo con Tesseract su
    ogni pagina se pdf2image e' disponibile."""
    try:
        from pdf2image import convert_from_path
        pagine = convert_from_path(pdf_path, dpi=CONFIG["DPI"])
        import pytesseract
        pytesseract.pytesseract.tesseract_cmd = CONFIG["TESSERACT_PATH"]
        testo = []
        for idx, img in enumerate(pagine, 1):
            testo.append(pytesseract.image_to_string(img, lang=CONFIG["OCR_LANG"]))
            log.info("OCR (PDF) pagina %d completata.", idx)
        return "\n".join(testo).strip()
    except ImportError:
        log.warning("pdf2image non installato: OCR sul PDF NAPS2 saltato. "
                    "(pip install pdf2image + Poppler) Uso nome di fallback.")
        return ""
    except Exception as e:
        log.error("OCR sul PDF fallito: %s", e)
        return ""


# ===========================================================================
# LLM LOCALE (Ollama) -> nome file
# ===========================================================================
SYSTEM_PROMPT = (
    "Sei un assistente che assegna nomi di file a documenti italiani scansionati. "
    "Ricevi il testo grezzo (OCR, che puo' contenere errori) e proponi UN SOLO "
    "nome file breve e descrittivo, SENZA estensione.\n"
    "\n"
    "COME RICONOSCERE IL DOCUMENTO E L'INTESTATARIO:\n"
    "- CARTA D'IDENTITA': contiene 'CARTA DI IDENTITA', 'COMUNE DI', i campi "
    "'COGNOME/SURNAME' e 'NOME/NAME'. L'intestatario e' COGNOME + NOME riportati "
    "in quei campi (di solito in MAIUSCOLO). Tipo documento: 'carta_identita'.\n"
    "- TESSERA SANITARIA / TEAM: contiene 'TESSERA SANITARIA', 'SERVIZIO SANITARIO "
    "NAZIONALE' o 'Tessera Europea Assicurazione Malattia'. L'intestatario e' il "
    "COGNOME e NOME stampati; c'e' anche il CODICE FISCALE (16 caratteri). "
    "Tipo documento: 'tessera_sanitaria'.\n"
    "- PATENTE: 'PATENTE DI GUIDA'. Tipo: 'patente'.\n"
    "- PASSAPORTO: 'PASSAPORTO/PASSPORT'. Tipo: 'passaporto'.\n"
    "- CODICE FISCALE (tesserino): 'CODICE FISCALE'. Tipo: 'codice_fiscale'.\n"
    "- Altri: fattura, bolletta, contratto, referto, lettera, ricevuta, busta_paga.\n"
    "\n"
    "REGOLE PER IL NOME:\n"
    "- Formato consigliato: <TipoDocumento>_<Cognome>_<Nome> (aggiungi la data "
    "AAAA-MM-GG solo se chiaramente presente e pertinente).\n"
    "- Correggi ovvi errori OCR nei nomi propri (es. '0'->'O', '1'->'I') quando "
    "sei ragionevolmente sicuro; mantieni Cognome e Nome con l'iniziale "
    "maiuscola.\n"
    "- NON inventare nomi: se il nome non e' leggibile, usa solo il tipo "
    "documento (es. 'tessera_sanitaria').\n"
    "- NON inserire mai nel nome il codice fiscale completo, numeri di documento "
    "o altri dati sensibili.\n"
    "- Usa SOLO lettere, numeri, underscore e trattini; spazi -> underscore.\n"
    "- Vietati i caratteri \\ / : * ? \" < > | e ogni carattere illegale su Windows.\n"
    "- Massimo 60 caratteri.\n"
    "\n"
    "ESEMPI:\n"
    "OCR: 'COMUNE DI MILANO CARTA DI IDENTITA COGNOME/SURNAME ROSSI NOME/NAME "
    "MARIO ...' -> {\"filename\":\"carta_identita_Rossi_Mario\"}\n"
    "OCR: 'SERVIZIO SANITARIO NAZIONALE TESSERA SANITARIA BIANCHI LUCIA "
    "CODICE FISCALE BNCLCU...' -> {\"filename\":\"tessera_sanitaria_Bianchi_Lucia\"}\n"
    "\n"
    "OUTPUT:\n"
    "- Rispondi ESCLUSIVAMENTE con un oggetto JSON valido: "
    '{\"filename\":\"nome_del_file\"}\n'
    "- Nessun testo prima o dopo il JSON, nessuna spiegazione."
)


def nome_da_llm(testo_ocr, log):
    """Chiede a Ollama un nome file pulito. Ritorna una stringa gia' sanificata,
    oppure None se fallisce (il chiamante usera' il fallback)."""
    import requests

    if not testo_ocr:
        return None

    # Limita il testo inviato (i modelli 3B hanno contesto ridotto)
    estratto = testo_ocr[:4000]

    payload = {
        "model": CONFIG["OLLAMA_MODEL"],
        "system": SYSTEM_PROMPT,
        "prompt": (
            "Testo OCR del documento (puo' contenere errori):\n"
            "-----\n" + estratto + "\n-----\n"
            "Restituisci solo il JSON con il nome file."
        ),
        "stream": False,
        "format": "json",           # forza output JSON su Ollama
        "options": {"temperature": 0.1},
    }

    try:
        r = requests.post(CONFIG["OLLAMA_URL"] + "/api/generate",
                          json=payload, timeout=CONFIG["OLLAMA_TIMEOUT"])
        r.raise_for_status()
        risposta = r.json().get("response", "")
        log.debug("Risposta LLM grezza: %s", risposta)
    except Exception as e:
        log.error("Chiamata a Ollama fallita: %s", e)
        return None

    nome = _estrai_filename(risposta, log)
    if not nome:
        return None
    return sanifica_nome(nome)


def _estrai_filename(risposta, log):
    """Parsing robusto: prova JSON diretto, poi regex sul campo filename."""
    if not risposta:
        return None
    # 1) JSON pulito
    try:
        obj = json.loads(risposta)
        if isinstance(obj, dict) and obj.get("filename"):
            return str(obj["filename"])
    except Exception:
        pass
    # 2) Cerca un blocco {...} nel testo
    m = re.search(r"\{.*?\}", risposta, re.DOTALL)
    if m:
        try:
            obj = json.loads(m.group(0))
            if obj.get("filename"):
                return str(obj["filename"])
        except Exception:
            pass
    # 3) Regex diretta "filename": "..."
    m = re.search(r'"filename"\s*:\s*"([^"]+)"', risposta)
    if m:
        return m.group(1)
    log.warning("Impossibile estrarre 'filename' dalla risposta LLM.")
    return None


# ===========================================================================
# SANIFICAZIONE NOME FILE
# ===========================================================================
def sanifica_nome(nome):
    """Rende il nome sicuro per Windows: rimuove caratteri illegali, spazi ->
    underscore, taglia a MAX_FILENAME_LEN."""
    if not nome:
        return ""
    nome = nome.strip().strip(".")
    # Rimuovi estensione eventuale
    nome = re.sub(r"\.(pdf|jpg|jpeg|png|txt)$", "", nome, flags=re.IGNORECASE)
    # Spazi -> underscore
    nome = re.sub(r"\s+", "_", nome)
    # Caratteri illegali Windows  \ / : * ? " < > |  + controllo
    nome = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "", nome)
    # Solo set sicuro
    nome = re.sub(r"[^A-Za-z0-9._\-]", "", nome)
    # Underscore multipli
    nome = re.sub(r"_+", "_", nome).strip("_-.")
    # Nomi riservati Windows
    riservati = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} \
        | {f"LPT{i}" for i in range(1, 10)}
    if nome.upper() in riservati:
        nome = "doc_" + nome
    return nome[:CONFIG["MAX_FILENAME_LEN"]].strip("_-.")


def nome_fallback():
    """Nome di riserva basato su timestamp."""
    return "scansione_" + datetime.now().strftime("%Y%m%d_%H%M%S")


def percorso_univoco(cartella, nome_base, estensione=".pdf"):
    """Aggiunge _2, _3, ... se il file esiste gia'."""
    candidato = os.path.join(cartella, nome_base + estensione)
    if not os.path.exists(candidato):
        return candidato
    i = 2
    while True:
        candidato = os.path.join(cartella, f"{nome_base}_{i}{estensione}")
        if not os.path.exists(candidato):
            return candidato
        i += 1


# ===========================================================================
# PULIZIA TEMP
# ===========================================================================
def pulisci_temp(temp_dir, log):
    """Elimina i file temporanei."""
    try:
        for f in os.listdir(temp_dir):
            try:
                os.remove(os.path.join(temp_dir, f))
            except Exception:
                pass
        os.rmdir(temp_dir)
        log.info("File temporanei eliminati.")
    except Exception as e:
        log.warning("Pulizia temp non completata: %s", e)


# ===========================================================================
# MAIN
# ===========================================================================
def main():
    parser = argparse.ArgumentParser(description="Scansione Brother + OCR + naming LLM")
    parser.add_argument("--device-id", help="Forza un DEVICE_ID WIA")
    parser.add_argument("--naps2", action="store_true", help="Usa il fallback NAPS2")
    parser.add_argument("--list-devices", action="store_true",
                        help="Elenca i device WIA ed esci")
    args = parser.parse_args()

    log = setup_logging(CONFIG["LOG_DIR"])
    log.info("=== Avvio scan_brother_ai ===")

    # Solo elenco device
    if args.list_devices:
        try:
            log.info("Device WIA disponibili:")
            elenca_device_wia(log)
        except Exception as e:
            log.error("Errore elenco device: %s", e)
        return

    # Controllo dipendenze
    try:
        controlla_dipendenze(log, usa_naps2=args.naps2)
    except RuntimeError as e:
        log.error(str(e))
        input("\nPremi INVIO per uscire...")
        sys.exit(1)

    os.makedirs(CONFIG["OUTPUT_DIR"], exist_ok=True)
    temp_dir = tempfile.mkdtemp(prefix="scan_", dir=os.environ.get("TEMP"))
    log.info("Cartella temporanea: %s", temp_dir)

    immagini = []
    pdf_temp = None
    try:
        # 1) SCANSIONE
        if args.naps2:
            pdf_temp = scansione_naps2_fallback(temp_dir, log)
            testo = ocr_da_pdf(pdf_temp, log)
        else:
            try:
                immagini = scansiona_wia(temp_dir, log, args.device_id)
            except RuntimeError as e:
                log.error("Scansione WIA fallita: %s", e)
                log.info("Suggerimento: prova il fallback NAPS2 con --naps2")
                raise
            # 3) OCR (sulle immagini)
            testo = ocr_testo(immagini, log)

        # 2) PDF temporaneo (se percorso immagini)
        if not args.naps2:
            pdf_temp = os.path.join(temp_dir, "documento.pdf")
            immagini_in_pdf(immagini, pdf_temp, log)

        # 4) NOME via LLM
        log.info("Richiesta nome file al modello '%s'...", CONFIG["OLLAMA_MODEL"])
        nome = nome_da_llm(testo, log)
        if not nome:
            nome = nome_fallback()
            log.warning("Uso nome di fallback: %s", nome)
        else:
            log.info("Nome proposto dall'LLM: %s", nome)

        # 5) SALVATAGGIO definitivo
        destinazione = percorso_univoco(CONFIG["OUTPUT_DIR"], nome, ".pdf")
        import shutil
        shutil.copy2(pdf_temp, destinazione)
        log.info("PDF salvato in: %s", destinazione)
        print("\n==============================================")
        print(f" DOCUMENTO SALVATO:\n   {destinazione}")
        print("==============================================\n")

    except Exception as e:
        log.error("Processo interrotto: %s", e)
        input("\nPremi INVIO per uscire...")
        sys.exit(1)
    finally:
        # 5) pulizia temp
        pulisci_temp(temp_dir, log)

    log.info("=== Fine ===")
    # Pausa finale utile in caso di doppio click
    input("Premi INVIO per chiudere...")


if __name__ == "__main__":
    main()
